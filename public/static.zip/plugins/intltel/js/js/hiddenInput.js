var input = document.querySelector("#phone");
window.intlTelInput(input, {
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1581331045115" // just for formatting/placeholders etc
});
