@extends('layouts.dash.main')
@section('title', 'Trading Dashboard - '.config('app.name'))
@section('trade-active', 'active')
@section('content')

@include('layouts.dash.wallet')

<div class="row mb-5">
    @if($wallet->amount < 100)
        @section('input-js')
            <script>
                $('#tradingInfo').modal();
            </script>
        @endsection
        <div class="modal fade" style="margin-top: 50px" id="tradingInfo" tabindex="-1" role="dialog" aria-labelledby="tradingInfoLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="background-color: black; ">
                    <div class="modal-header text-white">
                        Insufficient Funds on Trading Account.
                        <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </a>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-warning" style="font-size: 16px">
                            Sorry, your trading dashboard is not active at the moment due to insufficient funds.<br>*<br>
                            You need a minimum of $100 in your account to activate your trading dashboard for the first time.<br>*<br>
                            So that you can start buying, selling and trading.
                            <br>*<br>
                            <a class="btn btn-danger" href="{{ route('user.fund_wallet') }}">Click on this link to make a deposit and start trading!</a>
                            <br>*<br>
                            In need of any help, you can talk to us on the live chat for further assistance. Thanks!
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-secondary" data-dismiss="modal">Close</a>
                    </div>
                </div>
            </div>
        </div>

    @endif
    <div class="col-md-12"><!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container" style="margin-left: -28px">
          <div id="tradingview_1f4dd"></div>
          {{-- <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/FX_IDC-USDEUR/" rel="noopener" target="_blank"><span class="blue-text">USDEUR Chart</span></a> by TradingView</div> --}}
          <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
          <script type="text/javascript">
            new TradingView.widget(
                {
                "width": 1085,
                "height": 610,
                "symbol": "FX_IDC:USDEUR",
                "timezone": "Etc/UTC",
                "theme": "dark",
                "style": "1",
                "locale": "en",
                "toolbar_bg": "#f1f3f6",
                "enable_publishing": false,
                "withdateranges": true,
                "range": "ytd",
                "hide_side_toolbar": false,
                "allow_symbol_change": true,
                "details": true,
                "calendar": true,
                "container_id": "tradingview_1f4dd"
                }
            );
          </script>
        </div>
        <!-- TradingView Widget END -->

        {{-- <div class="row">
            <div class="col-md-12"> --}}
    </div>
    <div class="col-md-12">
        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container"style="margin-left: -28px">
            <div class="tradingview-widget-container__widget"></div>
            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>
            {
            "width": 1085,
            "height": 450,
            "currencies": [
            "EUR",
            "USD",
            "JPY",
            "GBP",
            "CHF",
            "AUD",
            "CAD",
            "NZD",
            "CNY"
            ],
            "isTransparent": false,
            "colorTheme": "dark",
            "locale": "en"
        }
            </script>
        </div>
        <!-- TradingView Widget END -->
    </div>
</div>

<!-- ============================================================== -->
<!-- end wallets  -->
<!-- ============================================================== -->
@endsection
