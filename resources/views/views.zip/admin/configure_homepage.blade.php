@extends('layouts.admin.main')
@section('title', 'Edit Homepage - nwallet')
@section('page-title', 'Edit Homepage')
@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('suser.home') }}">Home</a></li>
    <li class="breadcrumb-item"><a href="{{ route('suser.configure_nwallet') }}">Configure nwallet</a></li>
    <li class="breadcrumb-item active" aria-current="page">@yield('page-title')</li>
@endsection

@section('content')
<div class="row">
	<div class="container">
	    <div class="col-12">
	    	<div class="row">
		    	<div class="col-12">
			        @if(session()->has('success'))
			          <div class="alert alert-success">
			            {{ session()->get('success') }}
			          </div>
			        @endif
			        @if(session()->has('failed'))
			          <div class="alert alert-danger">
			            {{ session()->get('failed') }}
			          </div>
			        @endif
		     	</div>
		    </div>
		    <form action="{{ route('suser.configure_homepage') }}" method="post" enctype="multipart/form-data">
		    	@csrf
			    <div class="row text-center">
			    	<div class="col-12">
			    		{{-- Header --}}
			    		<div class="row">
			    			<div class="col-md-7">
				    			<h6>Header</h6>
				    			<textarea type="text" class="form-control" placeholder="Header body" name="header_body" maxlength="1000" rows="3" style="resize: none">{{ $header->body }}</textarea>
				    		</div>
				    		<div class="col-md-5">
				    			<input type="file" class="form-control-file border mb-4" name="header_img" id="header_img" accept="image/*" value="{{ $header->img }}" hidden>
				    			<div class="btn-group">
				    				<label class="bordered" id="header_disp" disabled>{{ str_replace("homepage/", "", $header->img) }}</label><label for="header_img" class="btn btn-primary" style="cursor: pointer;">Change Image</label>
				    			</div>
                				<img src="{{ config('globals.path') }}/storage/{{ $header->img }}" alt=" " class="img-fluid">
				    		</div>
			    		</div>
			    		<hr>

			    		{{-- Section 1 --}}
			    		<div class="row">
			    			<div class="col-sm-12 mb-4">
			    				<h6>Section 1</h6>
			    			</div>
			    			<div class="col-sm-12 mb-4">
			    				<input type="text" class="form-control" placeholder="Section 1 title" maxlength="255" name="section1_title" value="{{ $section1->title }}">
			    			</div>
			    			<div class="col-sm-12 mb-4">
			    				<textarea type="text" class="form-control" placeholder="Section 1 body" name="section1_body" maxlength="1000" rows="5" style="resize: none">{{ $section1->body }}</textarea>
			    			</div>
			    		</div>
			    		<hr>

			    		{{-- Section 2 --}}
			    		<div class="row">
			    			<div class="col-sm-12 mb-4">
			    				<h6>Section 2</h6>
			    			</div>
			    			<div class="col-md-7 mb-4">
			    				<input type="text" class="form-control" placeholder="Section 2 title" maxlength="255" name="section2_title" value="{{ $section2->title }}">
			    			</div>
			    			<div class="col-md-5 mb-4">
			    				<input type="file" class="form-control-file border mb-4" name="section2_img" accept="image/*" id="section2_img" hidden>
			    				<div class="btn-group">
				    				<label class="bordered" id="section2_disp" disabled>{{ str_replace("homepage/", "", $section2->img) }}</label><label for="section2_img" class="btn btn-primary" style="cursor: pointer;">Change Image</label>
				    			</div>
                				<img src="{{ config('globals.path') }}/storage/{{ $section2->img }}" alt=" " class="img-fluid">
			    			</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 2a</h6>
		    					<input type="text" class="form-control" placeholder="Section 2a title" maxlength="255" name="section2a_title" value="{{ $section2a->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 2a body" name="section2a_body" maxlength="1000" rows="5" style="resize: none">{{ $section2a->body }}</textarea>
		    				</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 2b</h6>
		    					<input type="text" class="form-control" placeholder="Section 2b title" maxlength="255" name="section2b_title" value="{{ $section2b->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 2b body" name="section2b_body" maxlength="1000" rows="5" style="resize: none">{{ $section2b->body }}</textarea>
		    				</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 2c</h6>
		    					<input type="text" class="form-control" placeholder="Section 2c title" maxlength="255" name="section2c_title" value="{{ $section2c->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 2c body" name="section2c_body" maxlength="1000" rows="5" style="resize: none">{{ $section2c->body }}</textarea>
		    				</div>
			    		</div>
			    		<hr>

			    		{{-- Section 3 --}}
			    		<div class="row">
			    			<div class="col-md-7 mb-4">
			    				<h6>Section 3</h6>
			    				<input type="text" class="form-control" placeholder="Section 3 title" maxlength="255" name="section3_title" value="{{ $section3->title }}">
			    				<textarea type="text" class="form-control" placeholder="Section 3 body" name="section3_body" maxlength="1000" rows="5" style="resize: none">{{ $section3->body }}</textarea>
			    			</div>
			    			<div class="col-md-5 mb-4">
			    				<input type="file" class="form-control-file border mb-4" name="section3_img" accept="image/*" id="section3_img" hidden>
			    				<div class="btn-group">
				    				<label class="bordered" id="section3_disp" disabled>{{ str_replace("homepage/", "", $section3->img) }}</label><label for="section3_img" class="btn btn-primary" style="cursor: pointer;">Change Image</label>
				    			</div>
                				<img src="{{ config('globals.path') }}/storage/{{ $section3->img }}" alt=" " class="img-fluid">
			    			</div>
		    				<div class="col-md-6 mb-4">
			    				<input type="file" class="form-control-file border mb-4" name="section3a_img" accept="image/*" id="section3a_img" hidden>
			    				<div class="btn-group">
				    				<label class="bordered" id="section3a_disp" disabled>{{ str_replace("homepage/", "", $section3a->img) }}</label><label for="section3a_img" class="btn btn-primary" style="cursor: pointer;">Change Image</label>
				    			</div>
                				<img src="{{ config('globals.path') }}/storage/{{ $section3a->img }}" alt=" " class="img-fluid">
			    			</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 3b</h6>
		    					<input type="text" class="form-control" placeholder="Section 3b title" maxlength="255" name="section3b_title" value="{{ $section3b->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 3b body" name="section3b_body" maxlength="1000" rows="5" style="resize: none">{{ $section3b->body }}</textarea>
		    				</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 3c</h6>
		    					<input type="text" class="form-control" placeholder="Section 3c title" maxlength="255" name="section3c_title" value="{{ $section3c->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 3c body" name="section3c_body" maxlength="1000" rows="5" style="resize: none">{{ $section3c->body }}</textarea>
		    				</div>
		    				<div class="col-md-6 mb-4">
		    					<h6>Section 3d</h6>
		    					<input type="text" class="form-control" placeholder="Section 3d title" maxlength="255" name="section3d_title" value="{{ $section3d->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 3d body" name="section3d_body" maxlength="1000" rows="5" style="resize: none">{{ $section3d->body }}</textarea>
		    				</div>
			    		</div>
			    		<hr>

			    		{{-- Section 4 --}}
			    		<div class="row">
			    			<div class="col-md-7 mb-4">
			    				<h6>Section 4</h6>
			    				<input type="text" class="form-control" placeholder="Section 4 title" maxlength="255" name="section4_title" value="{{ $section4->title }}">
			    			</div>
			    			<div class="col-md-5 mb-4">
			    				<input type="file" class="form-control-file border mb-4" name="section4_img" accept="image/*" id="section4_img" value="{{ $section4->img }}" hidden>
			    				<div class="btn-group">
				    				<label class="bordered" id="section4_disp" disabled>{{ str_replace("homepage/", "", $section4->img) }}</label><label for="section4_img" class="btn btn-primary" style="cursor: pointer;">Change Image</label>
				    			</div>
                				<img src="{{ config('globals.path') }}/storage/{{ $section4->img }}" alt=" " class="img-fluid">
			    			</div>
		    				<div class="col-sm-6 col-md-4 mb-4">
		    					<h6>Section 4a</h6>
		    					<input type="text" class="form-control" placeholder="Section 4a title" maxlength="255" name="section4a_title" value="{{ $section4a->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 4a body" name="section4a_body" maxlength="1000" rows="5" style="resize: none">{{ $section4a->body }}</textarea>
		    				</div>
		    				<div class="col-sm-6 col-md-4 mb-4">
		    					<h6>Section 4b</h6>
		    					<input type="text" class="form-control" placeholder="Section 4b title" maxlength="255" name="section4b_title" value="{{ $section4b->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 4b body" name="section4b_body" maxlength="1000" rows="5" style="resize: none">{{ $section4b->body }}</textarea>
		    				</div>
		    				<div class="col-sm-6 col-md-4 mb-4">
		    					<h6>{{ ucfirst($section4c->name) }}</h6>
		    					<input type="text" class="form-control" placeholder="Section 4c title" maxlength="255" name="section4c_title" value="{{ $section4c->title }}">
		    					<textarea type="text" class="form-control" placeholder="Section 4c body" name="section4c_body" maxlength="1000" rows="5" style="resize: none">{{ $section4c->body }}</textarea>
		    				</div>
			    		</div>
			    		<hr>

			    		{{-- Footer --}}
			    		<div class="row">
			    			<div class="col-sm-6 mb-4">
			    				<h6>{{ ucfirst($footer_a->name) }}</h6>
			    				<textarea type="text" class="form-control" placeholder="Footer a body" name="footer_a_body" maxlength="1000" rows="5" style="resize: none">{{ $footer_a->body }}</textarea>
			    			</div>
			    			<div class="col-sm-6 mb-4">
			    				<h6>{{ ucfirst($footer_b->name) }}</h6>
			    				<input type="text" class="form-control mb-4" placeholder="Footer b title" maxlength="255" name="footer_b_title" value="{{ $footer_b->title }}">
			    				<h6>{{ ucfirst($contact_a->name) }}</h6>
			    				<input type="text" class="form-control mb-4" placeholder="Address" maxlength="255" name="contact_a" value="{{ $contact_a->body }}">
			    				<h6>{{ ucfirst($contact_p->name) }}</h6>
			    				<input type="text" class="form-control mb-4 num" placeholder="Phone Number" maxlength="255" name="contact_p" value="{{ $contact_p->body }}">
			    				<h6>{{ ucfirst($contact_e->name) }}</h6>
			    				<input type="email" class="form-control mb-4" placeholder="Email Address" maxlength="255" name="contact_e" value="{{ $contact_e->body }}">
			    			</div>
			    		</div>
			    		<hr>

			    		{{-- Social Network --}}
			    		<div class="row mb-4">
			    			<div class="col-sm-6 col-md-4">
			    				<h6>{{ ucfirst($social_f->name) }}</h6>
			    				<input type="text" class="form-control mb-4" placeholder="Facebook Link" maxlength="255" name="social_f" value="{{ $social_f->body }}">
			    			</div>
			    			<div class="col-sm-6 col-md-4 mb-4">
			    				<h6>{{ ucfirst($social_t->name) }}</h6>
			    				<input type="text" class="form-control mb-4" placeholder="Twitter Link" maxlength="255" name="social_t" value="{{ $social_t->body }}">
			    			</div>
			    			<div class="col-sm-6 col-md-4 mb-4">
			    				<h6>{{ ucfirst($social_i->name) }}</h6>
			    				<input type="text" class="form-control mb-4" placeholder="Instagram Link" maxlength="255" name="social_i" value="{{ $social_i->body }}">
			    			</div>
			    		</div>
			    		<div class="row">
			    			<button class="btn btn-primary" type="submit">Save Changes</button>
			    		</div>
			    	</div>
			    </div>
			</form>
		    @if($errors->any())
		        <div class="col-12">
			      <div class="alert alert-danger">
			        <ul>
			          @foreach($errors->all() as $error)
			            <li>{{ $error }}</li>
			          @endforeach
			        </ul>
			      </div>
		        </div>
		    @endif
	    </div>
    </div>
  </div>
@endsection

@section('input-js')
<script>
	$('#header_img').on("change", function(){
	  // Name of file and placeholder
	  var file = this.files[0].name;
	  if($(this).val()){
	    $('#header_disp').text(file);
	  }
	});
	$('#section2_img').on("change", function(){
	  // Name of file and placeholder
	  var file = this.files[0].name;
	  if($(this).val()){
	    $('#section2_disp').text(file);
	  }
	});
	$('#section3_img').on("change", function(){
	  // Name of file and placeholder
	  var file = this.files[0].name;
	  if($(this).val()){
	    $('#section3_disp').text(file);
	  }
	});
    $('#section3a_img').on("change", function(){
	  // Name of file and placeholder
	  var file = this.files[0].name;
	  if($(this).val()){
	    $('#section3a_disp').text(file);
	  }
	});
	$('#section4_img').on("change", function(){
	  // Name of file and placeholder
	  var file = this.files[0].name;
	  if($(this).val()){
	    $('#section4_disp').text(file);
	  }
	});
</script>
@endsection
