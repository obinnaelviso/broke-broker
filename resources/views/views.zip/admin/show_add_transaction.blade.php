<div id="show_add_transaction" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">

            <form action="{{ route('suser.transactions.add') }}" method="POST">
                @csrf
                <div class="modal-header">
                  <h5 class="modal-title">Add Transactions</h5>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <table class="table table-striped" id="table-striped">
                        <tbody>
                            <tr>
                                <td>User</td>
                                <td>
                                    <select class="form-control" name="user_id" required>
                                        @foreach ($users as $user)
                                            <option value="{{ $user->id }}">{{ ucfirst($user->first_name.' '.$user->last_name) }}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Transaction Type</td>
                                <td><input type="text" class="form-control" name="prev_bal" placeholder="Enter Transaction Type"/></td>
                            </tr>
                            <tr>
                                <td>Amount</td>
                                <td><input type="text" class="form-control small-input num" name="amount" placeholder="0.00"/></td>
                            </tr>
                            <tr>
                                <td>Date</td>
                                <td><input type="text" class="form-control mb-4" name="created_at" id="datetimepicker" value="{{ old('created_at') }}" required readonly></td>
                            </tr>
                            <tr>
                                <td>Description</td>
                                <td><textarea type="text" class="form-control" placeholder="Enter Transaction Description" name="description" maxlength="255" rows="3" style="resize: none" required></textarea></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
          </form>
        </div>
    </div>
</div>
