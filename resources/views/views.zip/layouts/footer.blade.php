<footer>
  <div class="text-center">
    <p>Copyright ©<script>var CurrentYear = new Date().getFullYear()
    document.write(CurrentYear)</script> <a href="@config('app.url')">{{ config('app.name') }}</a></p>
  </div>
</footer>

