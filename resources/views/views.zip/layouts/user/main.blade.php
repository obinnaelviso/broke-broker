<!DOCTYPE html>
<html lang="zxx">
@include('layouts.head')
<body>
  @include('layouts.user.header')
  @include('layouts.user.wallet')
  @include('layouts.user.body')
  @include('layouts.footer')
  @include('layouts.js')
    <script>
        var accountNoVisible = false
        var account_no = '{{ $user->acc_no }}'
        $("#acc-no").html(account_no.substr(0,2) + 'XXXXXX' + account_no.substr(7,9))
        $("#show-acc-no").click(function() {
            if(accountNoVisible) {
                accountNoVisible = false
                $("#acc-no").html(account_no.substr(0,2) + 'XXXXXX' + account_no.substr(7,9))
                $("#show-acc-no").html('Show Account Number')
                $("#show-acc-no").attr('class', 'btn btn-danger')
            } else {
                accountNoVisible = true
                $("#acc-no").html(account_no)
                $("#show-acc-no").html('Hide Account Number')
                $("#show-acc-no").attr('class', 'btn btn-success')
            }
        })
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/5ce7b2b42135900bac124c97/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
</body>
</html>
