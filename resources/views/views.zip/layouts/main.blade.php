<!DOCTYPE html>
<html lang="zxx">
@include('layouts.head')
<body>
  @yield('content')
  @include('layouts.js')
</body>
</html>
