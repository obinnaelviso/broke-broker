<!DOCTYPE html>
<html lang="zxx">
@include('layouts.head')
<body>
  @include('layouts.admin.header')
  @include('layouts.admin.stats')
  @include('layouts.admin.body')
  @include('layouts.footer')
  @include('layouts.js')
</body>
</html>
