  <!-- preloader -->
  <div class="preloader">
    <div class="loader">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- /preloader -->

<header class="navigation">
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="{{ route('suser.home') }}" style="color: black; font-size: 32px; font-weight: 900;">7EVEN<span style="color: orange">TRADE</span>FX</a>
  <div class="collapse navbar-collapse text-center" id="navogation">
    <ul class="navbar-nav ml-auto">
     {{--  <li class="nav-item">
        <a class="nav-link text-uppercase text-dark btn btn-default" href="about.html" style="display: inline">About</a> XXX XXX
      </li> --}}
    </ul>
  </div>
</nav>
</header>
