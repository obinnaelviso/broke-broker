<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Balance</h2>
            {{-- <p class="pageheader-text">Get to manage all your wallets in one place</p> --}}
            <hr>
        </div>
    </div>
</div>

<!-- ============================================================== -->
<!-- wallets  -->
<!-- ============================================================== -->
<div class="row mb-5">
    <!-- ============================================================== -->
    <!-- USD  -->
    <!-- ============================================================== -->
    <div class="col-md-4">
        <div class="card border-3 border-top border-top-primary">
            <div class="card-body">
                <h5 class="text-muted">USD $</h5>
                <div class="metric-value d-inline-block">
                    <h1 class="mb-1">{{ $wallet->amount }}</h1>
                </div>
                {{-- <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                    <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1">5.86%</span>
                </div> --}}
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end USD  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- new customer  -->
    <!-- ============================================================== -->
    {{-- <div class="col-md-4">
        <div class="card border-3 border-top border-brand">
            <div class="card-body">
                <h5 class="text-muted">BTC <i class="fab fa-bitcoin"></i></h5>
                <div class="metric-value d-inline-block">
                    <h1 class="mb-1">{{ $wallet->btc }}</h1>
                </div>
            </div>
        </div>
    </div> --}}
    <!-- ============================================================== -->
    <!-- end new customer  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- visitor  -->
    <!-- ============================================================== -->
    {{-- <div class="col-md-4">
        <div class="card border-3 border-top border-top-dark">
            <div class="card-body">
                <h5 class="text-muted">Bonus $</h5>
                <div class="metric-value d-inline-block">
                    <h1 class="mb-1">{{ $wallet->bonus }}</h1>
                </div>
            </div>
        </div>
    </div> --}}
   <!-- ============================================================== -->
    <!-- end visitor  -->
    <!-- ============================================================== -->
    <div class="col-md-8">
        <a href="{{ url('/user/deposit') }}" class="btn btn-danger btn-block">Make Deposit</a>
        <a href="{{ url('/user/withdraw') }}" class="btn btn-success btn-block">Withdraw Funds</a>
        <a href="{{ url('/user/trade') }}" class="btn btn-primary btn-block">Start Trading</a>
    </div>
    {{-- <div class="col-md-6">
        <a href="{{ url('/user/withdraw') }}" class="btn btn-success btn-block">Withdraw Funds</a>
    </div> --}}
</div>
