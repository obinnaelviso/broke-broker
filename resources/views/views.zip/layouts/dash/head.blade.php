
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>@yield('title')</title>
	<link href="/images/favicon.png" rel="icon" type="image/png"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/dash/vendor/bootstrap/css/bootstrap.min.css">
    <link href="/dash/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="/dash/libs/css/style.css">
    <link rel="stylesheet" href="/dash/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <script src="https://kit.fontawesome.com/df87e06ba5.js" crossorigin="anonymous"></script>
</head>
