@component('mail::message')
<br><br>
Congratulations. Your account has been successfully authorized to receive OTP.<br>
Now you can receive OTP code for your all your transactions.
<br><br>
Thanks,<br>
{{ config('app.name') }}
@endcomponent
